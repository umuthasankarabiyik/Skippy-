# Skippy — a sarcastic desktop pet bullet for Linux

<!-- TODO: add a screenshot or GIF here:  ![Skippy](docs/screenshot.png) -->

A small always-on-top desktop companion: a golden bullet with red goggles and blue arms that floats on your screen,
makes sarcastic remarks, reminds you of things, and hides a few games and tools inside.
Built with Python and PyQt6, made for Manjaro / Arch and works on most Linux desktops (X11 / XWayland).
Skippy is local-only: **no internet, no accounts, no telemetry.**

*Türkçe özet aşağıda / Turkish summary below.*

## Features
- **Reminders & chat** — type "in 25 minutes brew tea" in the chat box; streaks, notepad, work/rest timer with coin rewards.
- **Tamagotchi mode** — food, drinks, cleaning, coins.
- **Mini games** — *Happy Slaughtering* (cyberpunk boomer shooter with weapons and a hack system) and *Neon City* (idle city builder).
- **Spoken lines** — eSpeak NG, Piper or any custom TTS command.
- **Voice commands** — "Skippy, open Firefox". Built-in template recognizer (no downloads), optional Vosk or custom command.
- **Game banter** — in games you whitelist, Skippy trash-talks enemies while you hold or mash the mouse button.
- **Custom skins** — drop PNG/GIF skins in; the floating animation and holographic base work for them too.
- **English and Turkish** — switch in Settings → 🌐 Language / Dil (or `skippy --lang en`).
- Hidden from the taskbar, no desktop notifications, light on CPU.

## Install
```bash
sudo pacman -S python-pyqt6                                      # required
sudo pacman -S qt6-multimedia espeak-ng python-numpy alsa-utils  # optional: sounds, speech, faster voice recognition, microphone
# download and unzip the project, open a terminal in its folder, then:
./install.sh          # installs to ~/.local, no root needed; remove with ./uninstall.sh
skippy                # or launch "Skippy" from your app menu
```
Arch / Manjaro package: `cd packaging && makepkg -si`. Without installing: `python3 pet.py`.

## Usage
Right-click Skippy for the menu, click for the chat. Drag him anywhere; he stays where you drop him.

**Game banter:** Settings → 🎮 Game banter → *Add the game that is open now*, then switch to the game within 5 seconds.
Skippy only talks in listed games (so he stays quiet in Minecraft). It reads the active window's name and the mouse
button state through X11 locally, nothing is stored or sent. Needs X11 / XWayland.
The taunts are crude, fictional and aimed at in-game enemies only; edit `GAME_TAUNTS` in `lines.py` to taste.

## Privacy
Everything stays on your machine. The microphone is only read while voice commands are switched on; the active window
and mouse state are only read while a whitelisted game is focused.

## Contributing
Feedback and improvements are welcome. Translations live in `i18n_en.py` (Turkish source text → English); to add a language,
add a table and a language code in `i18n.py`.

## License
Copyright (C) 2026 <your name>

This program is free software: you can redistribute it and/or modify it under the terms of the
[GNU General Public License v3.0](LICENSE) or (at your option) any later version. It is distributed in the hope that it
will be useful, but WITHOUT ANY WARRANTY. PyQt6 is also GPLv3 licensed, which is why this project uses the same license.

Skippy's personality is a fan homage to the character from Craig Alanson's *Expeditionary Force* novels; this project is
not affiliated with or endorsed by the author or publishers.

---

# Türkçe özet
Linux için alaycı bir masaüstü arkadaşı: kırmızı gözlüklü, mavi kollu altın bir mermi. Ekranda süzülür, hatırlatıcı kurar,
mini oyunlar (Happy Slaughtering, Neon Şehir), sesli konuşma ve sesli komut, seçtiğin oyunlarda düşmanlara laf atma gibi
özellikleri vardır. İnternet, hesap ya da veri toplama yoktur.

**Kurulum:** `sudo pacman -S python-pyqt6`, ardından `./install.sh` ve `skippy`. Dil: Ayarlar → 🌐 Language / Dil.
**Lisans:** GNU GPL v3 veya sonrası (bkz. `LICENSE`).
