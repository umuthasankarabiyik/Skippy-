Kişisel kullanım için görünüm paketi / personal-use skin. Başkasının görselleri: GitHub'a / Drive paylaşımına KOYMA.
